<?php

/**
 * This is a stub include that automatically configures the include path.
 */

require_once dirname(__FILE__) . '/HTMLPurifier/Bootstrap.php';
require_once dirname(__FILE__) . '/HTMLPurifier.autoload.php';

// vim: et sw=4 sts=4
